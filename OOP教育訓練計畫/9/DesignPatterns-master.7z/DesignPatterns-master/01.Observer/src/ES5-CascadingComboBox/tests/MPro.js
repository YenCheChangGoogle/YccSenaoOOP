var MPro = {
  "promotion": [
    {
      "id": "201700015",
      "name": "3G 699專案(30個月)",
      "children1": [
        {
          "id": "201700028",
          "name": "183+MPRO 950(30個月)(月繳699)",
          "children1": [
            {
              "id": "5",
              "name": "5-3G 183型",
              "parent": "201700028"
            }
          ],
          "children2": [],
          "children3": [
            {
              "id": "950",
              "name": "950-MPRO 950",
              "parent": "201700028"
            }
          ],
          "parent": "201700015"
        }
      ],
      "parent": "0"
    }
  ]
};