import {DigitalClock} from "./DigitalClock.js";

let options = {
    time: 'dc',
    period: 'dc_period',
    second: 'dc_second'
};

let digitalClock = new DigitalClock(options);